# SkilloVilla FrontEnd React Project

User listing widget that can be easily embedded in any website

### Functionalities

● Card based listing for provided user data.

● Search bar on the widget to search through user cards. Search can be done on
the user's name (first, last) & location (city, country).
